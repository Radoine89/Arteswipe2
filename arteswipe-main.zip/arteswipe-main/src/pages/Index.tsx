import { useState } from "react";
import AntiqueCard from "@/components/AntiqueCard";
import Navigation from "@/components/Navigation";
import { useToast } from "@/components/ui/use-toast";

// Données temporaires
const TEMP_ANTIQUES = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1588599376442-3cbf9c67449e",
    title: "Commode Louis XV",
    price: 2500,
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1581428982868-e410dd047a90",
    title: "Miroir Vénitien",
    price: 1800,
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1615529151169-7b1ff50dc7f2",
    title: "Vase Art Déco",
    price: 950,
  },
];

const Index = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { toast } = useToast();
  const [favorites, setFavorites] = useState<number[]>([]);

  const handleLike = () => {
    const currentAntique = TEMP_ANTIQUES[currentIndex];
    setFavorites([...favorites, currentAntique.id]);
    toast({
      title: "Ajouté aux favoris",
      description: `${currentAntique.title} a été ajouté à vos favoris`,
    });
    if (currentIndex < TEMP_ANTIQUES.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handleDislike = () => {
    if (currentIndex < TEMP_ANTIQUES.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <div className="min-h-screen bg-arteswipe-background pb-20">
      <div className="container py-8">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
          ArteSwipe
        </h1>
        {currentIndex < TEMP_ANTIQUES.length ? (
          <AntiqueCard
            {...TEMP_ANTIQUES[currentIndex]}
            onLike={handleLike}
            onDislike={handleDislike}
          />
        ) : (
          <div className="text-center text-gray-500 mt-12">
            Plus d'antiquités disponibles pour le moment
          </div>
        )}
      </div>
      <Navigation />
    </div>
  );
};

export default Index;