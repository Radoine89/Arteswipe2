import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

const Deposer = () => {
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Bientôt disponible",
      description: "La fonction de dépôt d'annonce sera bientôt disponible",
    });
  };

  return (
    <div className="min-h-screen bg-arteswipe-background pb-20">
      <div className="container py-8">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
          Déposer une annonce
        </h1>
        <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
          <Button type="submit" className="w-full">
            Déposer une annonce
          </Button>
        </form>
      </div>
      <Navigation />
    </div>
  );
};

export default Deposer;