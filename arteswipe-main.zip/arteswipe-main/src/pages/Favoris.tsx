import Navigation from "@/components/Navigation";

const Favoris = () => {
  return (
    <div className="min-h-screen bg-arteswipe-background pb-20">
      <div className="container py-8">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
          Mes Favoris
        </h1>
        <div className="text-center text-gray-500 mt-12">
          Vos objets favoris apparaîtront ici
        </div>
      </div>
      <Navigation />
    </div>
  );
};

export default Favoris;