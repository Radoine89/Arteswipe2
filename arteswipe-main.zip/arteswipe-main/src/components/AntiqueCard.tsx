import { Heart, X } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";
import { toast } from "./ui/use-toast";

interface AntiqueCardProps {
  image: string;
  title: string;
  price: number;
  onLike: () => void;
  onDislike: () => void;
}

const AntiqueCard = ({ image, title, price, onLike, onDislike }: AntiqueCardProps) => {
  const [direction, setDirection] = useState<"left" | "right" | null>(null);

  const handleLike = () => {
    setDirection("right");
    setTimeout(() => {
      onLike();
      setDirection(null);
    }, 300);
  };

  const handleDislike = () => {
    setDirection("left");
    setTimeout(() => {
      onDislike();
      setDirection(null);
    }, 300);
  };

  const handleBuy = () => {
    toast({
      title: "Achat en cours",
      description: "Cette fonctionnalité sera bientôt disponible",
    });
  };

  return (
    <div
      className={`relative w-full max-w-sm mx-auto aspect-[3/4] rounded-2xl overflow-hidden shadow-xl 
      ${direction === "left" ? "animate-slide-left" : ""} 
      ${direction === "right" ? "animate-slide-right" : ""}`}
    >
      <img
        src={image}
        alt={title}
        className="w-full h-full object-cover"
      />
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 text-white">
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-lg font-bold mb-4">{price.toLocaleString('fr-FR')} €</p>
        <Button 
          onClick={handleBuy}
          className="w-full bg-green-500 hover:bg-green-600 text-white font-bold"
        >
          Acheter
        </Button>
      </div>
      <div className="absolute top-1/2 left-0 right-0 -translate-y-1/2 flex justify-between px-4">
        <Button
          onClick={handleDislike}
          size="icon"
          className="h-14 w-14 rounded-full bg-white hover:bg-white/90 text-arteswipe-red"
        >
          <X className="h-8 w-8" />
        </Button>
        <Button
          onClick={handleLike}
          size="icon"
          className="h-14 w-14 rounded-full bg-white hover:bg-white/90 text-arteswipe-red"
        >
          <Heart className="h-8 w-8" />
        </Button>
      </div>
    </div>
  );
};

export default AntiqueCard;