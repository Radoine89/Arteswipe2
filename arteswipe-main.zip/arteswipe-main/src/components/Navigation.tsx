import { Heart, PlusCircle, ShoppingBag } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const Navigation = () => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4">
      <div className="max-w-lg mx-auto flex justify-around items-center">
        <Link
          to="/"
          className={`flex flex-col items-center ${
            isActive("/") ? "text-arteswipe-red" : "text-gray-500"
          }`}
        >
          <ShoppingBag size={24} />
          <span className="text-xs mt-1">Explorer</span>
        </Link>
        <Link
          to="/favoris"
          className={`flex flex-col items-center ${
            isActive("/favoris") ? "text-arteswipe-red" : "text-gray-500"
          }`}
        >
          <Heart size={24} />
          <span className="text-xs mt-1">Favoris</span>
        </Link>
        <Link
          to="/deposer"
          className={`flex flex-col items-center ${
            isActive("/deposer") ? "text-arteswipe-red" : "text-gray-500"
          }`}
        >
          <PlusCircle size={24} />
          <span className="text-xs mt-1">Déposer</span>
        </Link>
      </div>
    </nav>
  );
};

export default Navigation;